#!/usr/bin/env bash
set -Eeuo pipefail

# Usage:
# sudo ./capture.sh INTERFACE LABEL [DURATION_SECONDS]
# Example:
# sudo ./capture.sh tap0 normal 60

if [[ $EUID -ne 0 ]]; then
    echo "Run this script with sudo."
    exit 1
fi

if [[ $# -lt 2 || $# -gt 3 ]]; then
    echo "Usage: sudo $0 INTERFACE LABEL [DURATION_SECONDS]"
    exit 1
fi

IFACE="$1"
LABEL="$2"
DURATION="${3:-60}"

if [[ ! "$LABEL" =~ ^[a-zA-Z0-9_-]+$ ]]; then
    echo "LABEL may contain only letters, numbers, _ and -."
    exit 1
fi

if [[ ! "$DURATION" =~ ^[0-9]+$ ]] || (( DURATION < 1 )); then
    echo "Duration must be a positive integer."
    exit 1
fi

if [[ ! -d "/sys/class/net/$IFACE" ]]; then
    echo "Interface '$IFACE' does not exist."
    ip -br link
    exit 1
fi

BASE="/home/${SUDO_USER:-$(logname)}/FirmSight/network"
PCAP_DIR="$BASE/pcap"
LOG_DIR="$BASE/logs"

mkdir -p "$PCAP_DIR" "$LOG_DIR"

STAMP="$(date +%Y%m%d_%H%M%S)"
PCAP="$PCAP_DIR/${LABEL}_${STAMP}.pcap"
LOG="$LOG_DIR/${LABEL}_${STAMP}_capture.log"

echo "Interface: $IFACE"
echo "Label: $LABEL"
echo "Duration: $DURATION seconds"
echo "PCAP: $PCAP"
echo "Capture log: $LOG"

{
    echo "Start time: $(date --iso-8601=seconds)"
    echo "Interface: $IFACE"
    echo "Label: $LABEL"
    echo "Duration: $DURATION seconds"
} | tee "$LOG"

# Capture packets until the duration expires or the process is interrupted.
timeout --signal=INT "${DURATION}s" \
    tcpdump -i "$IFACE" -nn -s 0 -U -w "$PCAP" \
    2>&1 | tee -a "$LOG" || {
        status=${PIPESTATUS[0]}
        if (( status != 0 && status != 124 )); then
            echo "Capture failed with status $status" | tee -a "$LOG"
            exit "$status"
        fi
    }

echo "End time: $(date --iso-8601=seconds)" | tee -a "$LOG"

if [[ -f "$PCAP" ]]; then
    chmod 644 "$PCAP" "$LOG"
    echo "Capture finished: $PCAP"
    tcpdump -nn -r "$PCAP" -c 5 2>&1 | tee -a "$LOG"
else
    echo "ERROR: PCAP file was not created."
    exit 1
fi
