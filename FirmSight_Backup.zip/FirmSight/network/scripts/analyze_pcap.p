#!/usr/bin/env python3

import argparse
import csv
import json
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

FIELDS = [
    "frame.number",
    "frame.time_epoch",
    "frame.time",
    "_ws.col.Protocol",
    "eth.src",
    "eth.dst",
    "ip.src",
    "ip.dst",
    "ipv6.src",
    "ipv6.dst",
    "tcp.srcport",
    "tcp.dstport",
    "udp.srcport",
    "udp.dstport",
    "frame.len",
]

def main():
    parser = argparse.ArgumentParser(
        description="Extract network events from a PCAP file."
    )
    parser.add_argument("pcap", help="Path to input PCAP/PCAPNG")
    parser.add_argument(
        "--outdir",
        default=None,
        help="Output directory (default: ../logs relative to network/pcap)",
    )
    args = parser.parse_args()

    pcap = Path(args.pcap).expanduser().resolve()

    if not pcap.is_file():
        parser.error(f"PCAP file not found: {pcap}")

    if shutil.which("tshark") is None:
        sys.exit("Error: tshark is not installed. Install it with apt.")

    if args.outdir:
        outdir = Path(args.outdir).expanduser().resolve()
    else:
        outdir = pcap.parent.parent / "logs"

    outdir.mkdir(parents=True, exist_ok=True)

    stem = pcap.stem
    csv_path = outdir / f"{stem}_events.csv"
    jsonl_path = outdir / f"{stem}_events.jsonl"

    command = [
        "tshark",
        "-n",
        "-r", str(pcap),
        "-T", "fields",
        "-E", "header=y",
        "-E", "separator=,",
        "-E", "quote=d",
        "-E", "occurrence=f",
    ]

    for field in FIELDS:
        command.extend(["-e", field])

    try:
        result = subprocess.run(
            command,
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError as exc:
        sys.exit(
            "tshark failed:\n" + (exc.stderr or "No error details available")
        )

    rows_written = 0

    with csv_path.open("w", newline="", encoding="utf-8") as csv_file, \
         jsonl_path.open("w", encoding="utf-8") as jsonl_file:

        writer = csv.DictWriter(
            csv_file,
            fieldnames=FIELDS,
            extrasaction="ignore",
        )
        writer.writeheader()

        reader = csv.DictReader(result.stdout.splitlines())

        for row in reader:
            if not row.get("frame.number"):
                continue

            writer.writerow(row)

            timestamp = row.get("frame.time_epoch", "")
            try:
                timestamp_float = float(timestamp)
                utc_time = datetime.fromtimestamp(
                    timestamp_float, tz=timezone.utc
                ).isoformat()
            except (ValueError, OverflowError, OSError):
                utc_time = ""

            event = {
                "timestamp_epoch": timestamp,
                "timestamp_utc": utc_time,
                "frame_number": row.get("frame.number", ""),
                "protocol": row.get("_ws.col.Protocol", ""),
                "source_mac": row.get("eth.src", ""),
                "destination_mac": row.get("eth.dst", ""),
                "source_ip": row.get("ip.src") or row.get("ipv6.src", ""),
                "destination_ip": row.get("ip.dst") or row.get("ipv6.dst", ""),
                "source_port": row.get("tcp.srcport") or row.get("udp.srcport", ""),
                "destination_port": row.get("tcp.dstport") or row.get("udp.dstport", ""),
                "packet_length_bytes": row.get("frame.len", ""),
            }

            jsonl_file.write(json.dumps(event) + "\n")
            rows_written += 1

    print(f"Input PCAP: {pcap}")
    print(f"Packets processed: {rows_written}")
    print(f"CSV output: {csv_path}")
    print(f"JSONL output: {jsonl_path}")

    if rows_written == 0:
        print("WARNING: No packets decoded. Check the PCAP and capture interface.")

if __name__ == "__main__":
    main()
