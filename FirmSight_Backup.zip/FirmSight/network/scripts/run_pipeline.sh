#!/usr/bin/env bash
set -Eeuo pipefail

# Usage:
# sudo ./run_pipeline.sh INTERFACE LABEL [DURATION_SECONDS]

if [[ $EUID -ne 0 ]]; then
    echo "Run with sudo."
    exit 1
fi

if [[ $# -lt 2 || $# -gt 3 ]]; then
    echo "Usage: sudo $0 INTERFACE LABEL [DURATION_SECONDS]"
    exit 1
fi

IFACE="$1"
LABEL="$2"
DURATION="${3:-60}"

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
NETWORK_DIR="$(dirname "$SCRIPT_DIR")"
PCAP_DIR="$NETWORK_DIR/pcap"

# Record existing files so we can identify the new capture.
mkdir -p "$PCAP_DIR"

BEFORE="$(mktemp)"
AFTER="$(mktemp)"
trap 'rm -f "$BEFORE" "$AFTER"' EXIT

find "$PCAP_DIR" -maxdepth 1 -type f -name "${LABEL}_*.pcap" \
    -printf '%f\n' | sort > "$BEFORE"

"$SCRIPT_DIR/capture.sh" "$IFACE" "$LABEL" "$DURATION"

find "$PCAP_DIR" -maxdepth 1 -type f -name "${LABEL}_*.pcap" \
    -printf '%f\n' | sort > "$AFTER"

NEW_FILE="$(comm -13 "$BEFORE" "$AFTER" | tail -n 1)"

if [[ -z "$NEW_FILE" ]]; then
    echo "ERROR: Could not identify the newly created PCAP."
    exit 1
fi

python3 "$SCRIPT_DIR/analyze_pcap.py" "$PCAP_DIR/$NEW_FILE"

echo "Pipeline completed."
